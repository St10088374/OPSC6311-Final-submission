package com.example.final_source

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    private lateinit var bottomNavigationView: BottomNavigationView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNavigationView = findViewById(R.id.bottom_nav)

        bottomNavigationView.setOnItemSelectedListener { menuItem ->
            when(menuItem.itemId) {
                R.id.bttm_home -> {
                    replaceFragment(HomeFragment())
                    true
                }

                R.id.bttm_profile -> {
                    replaceFragment(ProfileFragment())
                    true
                }

                R.id.bttm_goal -> {
                    replaceFragment(AchievementFragment())
                    true
                }

                R.id.bttm_Cat -> {
                    replaceFragment(CategoryFragment())
                    true
                }

                R.id.bttm_add -> {
                    Toast.makeText(this,"upload images and text here", Toast.LENGTH_SHORT).show()
                    true
                }

                else -> false

            }
        }

        replaceFragment(HomeFragment())

    }

    private fun replaceFragment(fragment: Fragment)
    {
        supportFragmentManager.beginTransaction().replace(R.id.frame_con, fragment).commit()
    }

}