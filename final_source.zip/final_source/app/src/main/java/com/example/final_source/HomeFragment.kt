package com.example.final_source

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity

class HomeFragment : Fragment() {

    private lateinit var actionBar: ActionBar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        actionBar = (requireActivity() as AppCompatActivity).supportActionBar!!
        actionBar.title = "Home"



        val openActivityButton1 = view.findViewById<Button>(R.id.viewCatBtn)
        openActivityButton1.setOnClickListener {
            val intent = Intent(activity, viewCat::class.java)
            startActivity(intent)
        }

        return view
    }


}